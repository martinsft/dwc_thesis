# dwc_eval
Small test site for evaluating the dynamic wordcloud implementation
